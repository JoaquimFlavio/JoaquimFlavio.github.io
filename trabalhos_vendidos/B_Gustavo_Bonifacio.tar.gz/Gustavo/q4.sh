#!/bin/bash
# SEU NOME
# 2(sua serie)

#Utilizando o comando grep, filtramos todas as palavras com a letra "L" e "I"
#e as enviamos para o arquivo em tmp/q4.txt
echo $(grep L /tmp/q3.txt) >> /tmp/q4.txt 
echo $(grep I /tmp/q3.txt) >> /tmp/q4.txt 
