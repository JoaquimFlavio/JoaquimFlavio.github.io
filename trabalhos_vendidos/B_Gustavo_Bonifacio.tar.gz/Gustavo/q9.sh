#!/bin/bash
# SEU NOME
# 2(sua serie)

echo "entre com o nome do arquivo e sua extenção => ex.txt"
read file

mkdir cd /home/`whoami`/$file
