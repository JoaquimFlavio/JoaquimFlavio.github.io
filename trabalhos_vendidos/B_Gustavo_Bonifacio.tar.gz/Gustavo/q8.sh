#!/bin/bash
# SEU NOME
# 2(sua serie)


opcoes_inicio=( "(RR)" "(AP)" "(PA)" "(AM)" "(RO)" "(AC)" "(TO)" "(MA)" "(CE)" "(PI)" "(RN)" "(PB)" "(PE)" "(AL)" "(SE)" "(BA)" "(MG)" "(ES)" "(RJ)" "(SP)" "(MT)" "(DF)" "(GO)" "(MS)" "(PR)" "(SC)" "(RS)" )
opcoes_fim=( "Total Roraima" "Total Amapá:" "Total Pará:" "Total Amazonas:" "Total Rondonia:" "Total Acre:" "Total Tocantins:" "Total Maranhão:" "Total Ceará:" "Total Piauí:" "Total Rio Grande do Norte:" "Total Paraíba:" "Total Pernambuco:" "Total Alagoas:" "Total Sergipe:" "Total Bahia:" "Total Minas Gerais:" "Total Espírito Santo:" "Total Rio de Janeiro:" "Total São Paulo:" "Total Mato Grosso:" "Total Distrito Federal:" "Total Goiás:" "Total Mato Grosso do Sul:" "Total Paraná:" "Total Santa Catarina:" "Total Rio Grande do Sul:" )

#----------------------------------------------------------------------

echo `expr $(grep -c Sim /tmp/pec.txt) / 2` >> /tmp/q8a.txt
echo `expr $(grep -c Não /tmp/pec.txt) / 2` >> /tmp/q8a.txt

#----------------------------------------------------------------------

X=$(grep -n "${opcoes_inicio[6]}" /tmp/pec.txt | cut -d ":" -f 1)
Y=$(grep -n "${opcoes_fim[6]}" /tmp/pec.txt | cut -d ":" -f 1)
	
begin=`expr $X + 1`
finish=`expr $Y - $X + 1`
	
YEP=$(cat -n /tmp/pec.txt | tail -n +${begin} | head -n ${finish} | grep -c Sim)
NOP=$(cat -n /tmp/pec.txt | tail -n +${begin} | head -n ${finish} | grep -c Não)

echo -n "Sim:" >> /tmp/q8b.txt
echo $YEP >> /tmp/q8b.txt
echo -n " Não:" >> /tmp/q8b.txt
echo $NOP >> /tmp/q8b.txt

#----------------------------------------------------------------------

for position in {0..26}
do
	X=$(grep -n "${opcoes_inicio[$position]}" /tmp/pec.txt | cut -d ":" -f 1)
	Y=$(grep -n "${opcoes_fim[$position]}" /tmp/pec.txt | cut -d ":" -f 1)
	
	begin=`expr $X + 1`
	finish=`expr $Y - $X + 1`
	
	YEP=$(cat -n /tmp/pec.txt | tail -n +${begin} | head -n ${finish} | grep -c Sim)
	NOP=$(cat -n /tmp/pec.txt | tail -n +${begin} | head -n ${finish} | grep -c Não)
	
	echo -n ${opcoes_inicio[$position]} >> /tmp/q8c.txt
	echo -n "-> Sim:" >> /tmp/q8c.txt
	echo -n $YEP >> /tmp/q8c.txt
	echo -n " Não:" >> /tmp/q8c.txt
	echo $NOP >> /tmp/q8c.txt
done

#----------------------------------------------------------------------

echo $(cat -n /tmp/pec.txt | tail -n +507 | tr [:blank:] ';' | tr [:digit:] ';' | cut -d ";" -f 9,10 | tr ';' ' ') >> /tmp/q8d.txt

#----------------------------------------------------------------------

