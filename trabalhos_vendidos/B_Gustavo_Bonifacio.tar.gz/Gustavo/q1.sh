#!/bin/bash
# SEU NOME
# 2(sua serie)

echo "entre com o nome do usuario para pesquisa:" #imprime a msg para solicitar o nome.
read USR #Realiza a leitura do nome do usuario e armazena na variavel USR

#Declaração da função que realizará a busca do usuario no arquivo /etc/passwd
function _getUser()
{
	#busca a string "^$1\:x\:" dentro do arquivo, onde ^$1 e o parametro de busca
	#apos isso realizasse cortes nos caracteres desnecessarios, para que reste apenas
	#o nome do usuario buscado, e o msm, seja retornado pela função.
	grep "^$1\:x\:" /etc/passwd | \ 
	cut -d ':' -f 1 | \
	wc -c | \
	sed 's/[^0-9]//g'
}

#verifica se o retorno da função foi positivo.
if [ $( _getUser $USR ) -gt 3 ]; then
	echo "Usuario < $USR > encontrado."
	#imprime a linha em que foi encontrado o usuario no arquivo.
	grep -n $USR /etc/passwd | \cut -d ':' -f 1
	exit 0
fi
