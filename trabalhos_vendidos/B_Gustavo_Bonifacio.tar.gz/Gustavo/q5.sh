#!/bin/bash
# SEU NOME
# 2(sua serie)

#Utilizando o comando grep filtramos a letra desejada e apos isso cortamos
#a string na letra 'i' para que apenas a 1 letra seja enviada para o arquivo
echo $(grep L /tmp/q3.txt | cut -d "i" -f 1) >> /tmp/q5.txt
echo $(grep I /tmp/q3.txt | cut -d "i" -f 1) >> /tmp/q5.txt
echo $(grep N /tmp/q3.txt | cut -d "i" -f 1) >> /tmp/q5.txt
echo $(grep U /tmp/q3.txt | cut -d "i" -f 1) >> /tmp/q5.txt
echo $(grep X /tmp/q3.txt | cut -d "i" -f 1) >> /tmp/q5.txt
