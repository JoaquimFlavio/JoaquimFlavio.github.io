#!/bin/bash
# SEU NOME
# 2(sua serie)


#utilizando a variavel date, com o atributo m = ano criamos a pasta mes
mkdir /tmp/`date +%m`

