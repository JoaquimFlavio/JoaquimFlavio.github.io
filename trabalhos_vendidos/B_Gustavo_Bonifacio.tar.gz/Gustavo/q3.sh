#!/bin/bash
# SEU NOME
# 2(sua serie)

#declara-se dois arrays com todas as letras do alfabeto, minuscula e mauscula.
maiuscula=("A" "B" "C" "D" "E" "F" "G" "H" "I" "J" "K" "L" "M" "N" "O" "P" "Q" "R" "S" "T" "U" "V" "W" "X" "Y" "Z")
minuscula=("a" "b" "c" "d" "e" "f" "g" "h" "i" "j" "k" "l" "m" "n" "o" "p" "q" "r" "s" "t" "u" "v" "w" "x" "y" "z")

#Laço de repetição que será executado 26 vezes.
for i in {0..25}
do
	#escreve no arquivo a concatenação da letra maiuscula e minuscula 
	#da pozição referente ao laço de repetição
	echo ${maiuscula[i]}"inux" >> /tmp/q3.txt
	echo ${minuscula[i]}"inux" >> /tmp/q3.txt
done
