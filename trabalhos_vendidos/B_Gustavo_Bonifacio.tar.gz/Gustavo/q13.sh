#!/bin/bash
# SEU NOME
# 2(sua serie)


echo -n `date +%Y``date +%m``date +%d``date +%H``date +%M``date +%S`", " >> /tmp/q13.txt

