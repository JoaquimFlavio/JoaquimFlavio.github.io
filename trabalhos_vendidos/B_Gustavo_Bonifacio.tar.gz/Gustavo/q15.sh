#!/bin/bash
# SEU NOME
# 2(sua serie)

echo "entre com o seu nome"
#read nome
echo "entre com a data de nacimento"
#read data
data=21/10/1999

dia=$(echo $data | cut -d "/" -f 1)
mes=$(echo $data | cut -d "/" -f 2)
ano=$(echo $data | cut -d "/" -f 3)

y=`date +%Y`
m=`date +%m`
d=`date +%d`

echo $nome", vc tem "

if [$mes <= $m]; then
	if [dia < $d];	then
		echo -n "$y - $ano" | bc
	else
		echo -n "$y - $ano - 1" | bc
	fi
else
	echo -n "$y - $ano - 1" | bc
fi

echo -n "anos"
