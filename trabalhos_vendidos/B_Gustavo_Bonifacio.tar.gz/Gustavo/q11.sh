#!/bin/bash
# SEU NOME
# 2(sua serie)


#utilizando a variavel date, com o atributo Y = ano criamos a pasta ano
mkdir /tmp/`date +%Y`
#dentro da pasta ano criamos a pasta mes
mkdir /tmp/`date +%Y`/`date +%m`
#dentro da pasta mes, criamos a pasta dia
mkdir /tmp/`date +%Y`/`date +%m`/`date +%d`
