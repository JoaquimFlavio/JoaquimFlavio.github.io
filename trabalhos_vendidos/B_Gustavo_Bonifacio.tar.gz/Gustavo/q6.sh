#!/bin/bash
# SEU NOME
# 2(sua serie)

#abrimo o arquivo com o comando cat e apos isso utilizamos o comando TR,
#que realizará a inverção de maiuscula para minuscula.
echo $(cat /tmp/q5.txt | tr '[A-Za-z]' '[a-zA-Z]') >> /tmp/q6.txt
