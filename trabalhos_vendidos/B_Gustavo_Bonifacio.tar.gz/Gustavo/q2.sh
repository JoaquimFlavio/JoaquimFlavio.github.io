#!/bin/bash
# SEU NOME
# 2(sua serie)

echo "orato" >> /tmp/orato.txt

RATO=$(grep -c rato /tmp/orato.txt)
GATO=$(grep -c gato /tmp/orato.txt)
expr $RATO + $GATO
