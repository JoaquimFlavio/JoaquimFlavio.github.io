#!/bin/bash
# SEU NOME
# 2(sua serie)


echo $(wc -l /tmp/q3.txt | cut -d "/" -f -1)
